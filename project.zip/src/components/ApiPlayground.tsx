import { useState, useRef } from 'react';
import { Play, Loader2, CheckCircle, AlertCircle, Clock, Link } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { CodeBlock } from '@/components/CodeBlock';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;

type Status = 'idle' | 'loading' | 'success' | 'error';

const isValidUrl = (url: string): boolean => {
  try {
    new URL(url);
    return url.length > 10;
  } catch {
    return false;
  }
};

export const ApiPlayground = () => {
  const [pdfUrl, setPdfUrl] = useState('');
  const [response, setResponse] = useState<object | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [responseTime, setResponseTime] = useState<number | null>(null);
  const [status, setStatus] = useState<Status>('idle');
  const responseRef = useRef<HTMLDivElement>(null);

  const handleTest = async () => {
    if (!isValidUrl(pdfUrl)) {
      setError('Por favor, insira uma URL válida');
      setStatus('error');
      return;
    }

    setLoading(true);
    setError(null);
    setResponse(null);
    setStatus('loading');
    const startTime = Date.now();

    try {
      const res = await fetch(
        `${SUPABASE_URL}/functions/v1/process-pdf`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pdf_url: pdfUrl })
        }
      );

      const data = await res.json();
      setResponseTime(Date.now() - startTime);
      setResponse(data);
      setStatus(data.status === 'success' ? 'success' : 'error');
      
      if (data.status === 'error') {
        setError(data.message || 'Erro ao processar o PDF');
      }

      // Auto-scroll to response
      setTimeout(() => {
        responseRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    } catch (err) {
      setError('Falha ao conectar com a API. Verifique sua conexão.');
      setStatus('error');
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !loading && isValidUrl(pdfUrl)) {
      handleTest();
    }
  };

  const formatResponseTime = (ms: number): string => {
    if (ms < 1000) return `${ms}ms`;
    return `${(ms / 1000).toFixed(1)}s`;
  };

  return (
    <div className="space-y-6">
      {/* Input Section */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Link className="w-4 h-4" />
          <span>O PDF deve estar hospedado em uma URL pública e acessível</span>
        </div>
        
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <Input
              type="url"
              placeholder="https://exemplo.com/documento.pdf"
              value={pdfUrl}
              onChange={(e) => {
                setPdfUrl(e.target.value);
                if (status !== 'loading') setStatus('idle');
                setError(null);
              }}
              onKeyDown={handleKeyDown}
              disabled={loading}
              className="h-12 pr-4 font-mono text-sm bg-secondary/50 border-border focus:border-primary"
            />
          </div>
          
          <Button
            onClick={handleTest}
            disabled={loading || !pdfUrl.trim()}
            className="h-12 px-6 gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Processando...
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                Testar API
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Status Indicator */}
      {status !== 'idle' && (
        <div 
          className={`flex items-center gap-3 px-4 py-3 rounded-lg border transition-all ${
            status === 'loading' 
              ? 'bg-accent/10 border-accent/30 text-accent' 
              : status === 'success'
              ? 'bg-primary/10 border-primary/30 text-primary'
              : 'bg-destructive/10 border-destructive/30 text-destructive'
          }`}
        >
          {status === 'loading' && (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span className="font-medium">Processando PDF... Isso pode levar alguns segundos</span>
            </>
          )}
          {status === 'success' && (
            <>
              <CheckCircle className="w-5 h-5" />
              <span className="font-medium">PDF processado com sucesso!</span>
              {responseTime && (
                <span className="flex items-center gap-1 ml-auto text-sm opacity-80">
                  <Clock className="w-4 h-4" />
                  {formatResponseTime(responseTime)}
                </span>
              )}
            </>
          )}
          {status === 'error' && !loading && (
            <>
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">{error || 'Erro ao processar'}</span>
            </>
          )}
        </div>
      )}

      {/* Response Section */}
      {response && (
        <div ref={responseRef} className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold text-foreground">Resposta da API</h4>
            {responseTime && (
              <span className="text-xs text-muted-foreground">
                Tempo total: {formatResponseTime(responseTime)}
              </span>
            )}
          </div>
          <div className={`rounded-lg overflow-hidden border-2 ${
            status === 'success' ? 'border-primary/30' : 'border-destructive/30'
          }`}>
            <CodeBlock 
              code={JSON.stringify(response, null, 2)} 
              language="json" 
              title="application/json"
            />
          </div>
        </div>
      )}
    </div>
  );
};
