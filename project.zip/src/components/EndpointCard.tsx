import { ReactNode } from 'react';

interface EndpointCardProps {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  path: string;
  description: string;
  children: ReactNode;
}

export const EndpointCard = ({ method, path, description, children }: EndpointCardProps) => {
  const methodClass = method === 'POST' ? 'endpoint-post' : 'endpoint-get';

  return (
    <div className="rounded-xl border border-border bg-card p-6 space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <span className={`endpoint-badge ${methodClass}`}>{method}</span>
        <code className="text-lg font-mono text-foreground">{path}</code>
      </div>
      <p className="text-muted-foreground">{description}</p>
      {children}
    </div>
  );
};
