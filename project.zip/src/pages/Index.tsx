import { FileText, Zap, Shield, Database, Code, Table2, FlaskConical } from 'lucide-react';
import { Header } from '@/components/Header';
import { CodeBlock } from '@/components/CodeBlock';
import { EndpointCard } from '@/components/EndpointCard';
import { FeatureCard } from '@/components/FeatureCard';
import { ApiPlayground } from '@/components/ApiPlayground';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;

const requestExample = `{
  "pdf_url": "https://exemplo.com/documento.pdf"
}`;

const responseExample = `{
  "status": "success",
  "metadata": {
    "pages": 5,
    "file_name": "documento.pdf",
    "processed_at": "2025-01-30T12:00:00.000Z",
    "file_size_bytes": 245632
  },
  "content_raw": {
    "page_1": "Texto extraído da página 1...",
    "page_2": "Texto extraído da página 2..."
  },
  "content_structured": {
    "sections": [
      {
        "title": "Dados do Cliente",
        "fields": {
          "nome": "João Silva",
          "cpf": "123.456.789-00",
          "valor_total": 1234.56
        }
      }
    ]
  },
  "warnings": [],
  "confidence_score": 0.85
}`;

const curlExample = `curl -X POST \\
  ${SUPABASE_URL}/functions/v1/process-pdf \\
  -H "Content-Type: application/json" \\
  -d '{"pdf_url": "https://exemplo.com/documento.pdf"}'`;

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6 animate-fade-in">
            <Zap className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">API REST para documentos financeiros</span>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 animate-slide-up">
            Transforme PDFs em{' '}
            <span className="gradient-text">JSON estruturado</span>
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 animate-slide-up" style={{ animationDelay: '0.1s' }}>
            API REST que recebe URL de PDF, extrai texto com alta precisão e retorna dados estruturados usando IA.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <div className="status-badge status-success">
              <span className="w-2 h-2 rounded-full bg-primary mr-2" />
              Pronto para produção
            </div>
            <div className="status-badge bg-accent/20 text-accent">
              Volume médio: 100-1000/dia
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 border-y border-border bg-card/30">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-2xl font-bold text-foreground text-center mb-12">Funcionalidades</h2>
          
          <div className="grid md:grid-cols-3 gap-6">
            <FeatureCard
              icon={FileText}
              title="Extração Completa"
              description="Lê 100% das páginas, preservando ordem, cabeçalhos, rodapés e tabelas."
            />
            <FeatureCard
              icon={Database}
              title="Estruturação com IA"
              description="Identifica seções, normaliza valores monetários, datas e campos relevantes."
            />
            <FeatureCard
              icon={Shield}
              title="Validação Robusta"
              description="Verifica acessibilidade do PDF, valida formato e retorna erros claros."
            />
            <FeatureCard
              icon={Table2}
              title="Detecção de Tabelas"
              description="Identifica e extrai dados tabulares com estrutura preservada."
            />
            <FeatureCard
              icon={Code}
              title="JSON Limpo"
              description="Retorno padronizado com metadados, conteúdo bruto e estruturado."
            />
            <FeatureCard
              icon={Zap}
              title="Score de Confiança"
              description="Indica a qualidade da extração e possíveis conflitos de dados."
            />
          </div>
        </div>
      </section>

      {/* API Documentation */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-2xl font-bold text-foreground mb-8">Documentação da API</h2>
          
          <EndpointCard
            method="POST"
            path="/functions/v1/process-pdf"
            description="Processa um PDF a partir de uma URL pública e retorna os dados extraídos."
          >
            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-semibold text-foreground mb-3">Base URL</h4>
                <code className="text-sm font-mono text-primary bg-primary/10 px-3 py-1.5 rounded">
                  {SUPABASE_URL}
                </code>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold text-foreground mb-3">Request Body</h4>
                <CodeBlock code={requestExample} language="json" title="application/json" />
              </div>
              
              <div>
                <h4 className="text-sm font-semibold text-foreground mb-3">Response</h4>
                <CodeBlock code={responseExample} language="json" title="200 OK" />
              </div>
              
              <div>
                <h4 className="text-sm font-semibold text-foreground mb-3">Exemplo cURL</h4>
                <CodeBlock code={curlExample} language="bash" title="Terminal" />
              </div>
            </div>
          </EndpointCard>
        </div>
      </section>

      {/* API Playground */}
      <section className="py-16 px-4 border-t border-border">
        <div className="container mx-auto max-w-4xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 rounded-lg bg-accent/10 border border-accent/20">
              <FlaskConical className="w-5 h-5 text-accent" />
            </div>
            <h2 className="text-2xl font-bold text-foreground">Teste a API</h2>
          </div>
          <p className="text-muted-foreground mb-8">
            Cole uma URL de PDF público para testar a extração em tempo real.
          </p>
          <ApiPlayground />
        </div>
      </section>

      {/* Response Fields */}
      <section className="py-16 px-4 border-t border-border bg-card/30">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-2xl font-bold text-foreground mb-8">Campos da Resposta</h2>
          
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Campo</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Tipo</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Descrição</th>
                </tr>
              </thead>
              <tbody className="text-muted-foreground">
                <tr className="border-b border-border/50">
                  <td className="py-3 px-4 font-mono text-accent">status</td>
                  <td className="py-3 px-4">string</td>
                  <td className="py-3 px-4">"success" ou "error"</td>
                </tr>
                <tr className="border-b border-border/50">
                  <td className="py-3 px-4 font-mono text-accent">metadata</td>
                  <td className="py-3 px-4">object</td>
                  <td className="py-3 px-4">Informações do arquivo: páginas, nome, data de processamento</td>
                </tr>
                <tr className="border-b border-border/50">
                  <td className="py-3 px-4 font-mono text-accent">content_raw</td>
                  <td className="py-3 px-4">object</td>
                  <td className="py-3 px-4">Texto bruto extraído por página</td>
                </tr>
                <tr className="border-b border-border/50">
                  <td className="py-3 px-4 font-mono text-accent">content_structured</td>
                  <td className="py-3 px-4">object</td>
                  <td className="py-3 px-4">Dados estruturados com seções e campos identificados</td>
                </tr>
                <tr className="border-b border-border/50">
                  <td className="py-3 px-4 font-mono text-accent">warnings</td>
                  <td className="py-3 px-4">array</td>
                  <td className="py-3 px-4">Avisos sobre problemas encontrados</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-mono text-accent">confidence_score</td>
                  <td className="py-3 px-4">number</td>
                  <td className="py-3 px-4">Score de confiança da extração (0 a 1)</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border">
        <div className="container mx-auto max-w-4xl text-center text-sm text-muted-foreground">
          <p>PDF Parser API — Desenvolvido com Lovable Cloud</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
