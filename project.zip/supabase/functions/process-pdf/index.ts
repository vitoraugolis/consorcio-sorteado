import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

// Error codes for specific problems
type ErrorCode = 
  | 'INVALID_URL'           // URL mal formatada
  | 'DOWNLOAD_FAILED'       // Falha ao baixar o PDF
  | 'NOT_A_PDF'             // Arquivo não é um PDF válido
  | 'EMPTY_PDF'             // PDF vazio (0 bytes ou muito pequeno)
  | 'FILE_TOO_LARGE'        // PDF excede limite de tamanho
  | 'CORRUPTED_PDF'         // PDF corrompido (header inválido)
  | 'ENCRYPTED_PDF'         // PDF protegido por senha
  | 'UNREADABLE_CONTENT'    // Conteúdo extraído é ilegível/binário
  | 'EXTRACTION_FAILED'     // Ambos métodos de extração falharam
  | 'AI_PROCESSING_FAILED'  // Falha no processamento com IA
  | 'TIMEOUT'               // Timeout durante processamento
  | 'INTERNAL_ERROR';       // Erro interno não especificado

interface PDFRequest {
  pdf_url: string;
}

interface PDFResponse {
  status: 'success' | 'error' | 'partial';
  error_code?: ErrorCode;
  error_details?: string;
  metadata?: {
    pages: number;
    file_name: string;
    processed_at: string;
    file_size_bytes?: number;
    extraction_method: 'programmatic' | 'vision_api';
  };
  content_raw?: Record<string, string>;
  content_structured?: {
    dados_cadastrais?: Record<string, unknown>;
    dados_plano?: Record<string, unknown>;
    contemplacao?: Record<string, unknown>;
    resumo_financeiro?: Record<string, unknown>;
    pendencias?: Record<string, unknown>;
  };
  warnings: string[];
  confidence_score: number;
  error?: string;
}

// Error messages in Portuguese
function getErrorMessage(code: ErrorCode): string {
  const messages: Record<ErrorCode, string> = {
    'INVALID_URL': 'URL inválida',
    'DOWNLOAD_FAILED': 'Falha ao baixar o PDF',
    'NOT_A_PDF': 'O arquivo não é um PDF válido',
    'EMPTY_PDF': 'O PDF está vazio',
    'FILE_TOO_LARGE': 'O PDF excede o limite de tamanho',
    'CORRUPTED_PDF': 'O PDF está corrompido',
    'ENCRYPTED_PDF': 'O PDF está protegido por senha',
    'UNREADABLE_CONTENT': 'Conteúdo do PDF ilegível',
    'EXTRACTION_FAILED': 'Falha ao extrair texto do PDF',
    'AI_PROCESSING_FAILED': 'Falha no processamento com IA',
    'TIMEOUT': 'Tempo limite excedido',
    'INTERNAL_ERROR': 'Erro interno do servidor'
  };
  return messages[code];
}

// Create standardized error response - always returns HTTP 200
function createErrorResponse(
  code: ErrorCode, 
  details: string, 
  warnings: string[] = []
): Response {
  const response: PDFResponse = {
    status: 'error',
    error_code: code,
    error: getErrorMessage(code),
    error_details: details,
    warnings,
    confidence_score: 0
  };
  
  console.error(`Error response: ${code} - ${details}`);
  
  return new Response(
    JSON.stringify(response, null, 2),
    { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

// Clean and parse JSON with robust error handling
function cleanAndParseJSON(content: string): Record<string, unknown> {
  // Remove markdown code blocks
  let cleaned = content.replace(/```json\s*/gi, '').replace(/```\s*/gi, '');
  
  // Extract the JSON object
  const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    throw new Error('No JSON found in response');
  }
  
  // Try to parse directly first
  try {
    return JSON.parse(jsonMatch[0]);
  } catch {
    // Try to fix common issues
    let fixed = jsonMatch[0]
      .replace(/,\s*}/g, '}')  // Remove trailing commas before }
      .replace(/,\s*]/g, ']')  // Remove trailing commas before ]
      .replace(/[\x00-\x1F\x7F]/g, '') // Remove control characters
      .replace(/\n/g, ' ')  // Replace newlines with spaces
      .replace(/\r/g, '');  // Remove carriage returns
    
    try {
      return JSON.parse(fixed);
    } catch (e) {
      console.error('JSON parse failed even after cleanup:', e);
      throw new Error('Failed to parse JSON from AI response');
    }
  }
}

// Retry configuration
interface RetryConfig {
  maxRetries: number;
  initialDelayMs: number;
  maxDelayMs: number;
  retryableStatuses: number[];
}

const defaultRetryConfig: RetryConfig = {
  maxRetries: 3,
  initialDelayMs: 1000,      // 1 segundo inicial
  maxDelayMs: 10000,         // Máximo 10 segundos
  retryableStatuses: [429, 500, 502, 503, 504]  // Rate limit + server errors
};

// Fetch with exponential backoff retry
async function fetchWithRetry(
  url: string, 
  options: RequestInit, 
  config: Partial<RetryConfig> = {}
): Promise<Response> {
  const { maxRetries, initialDelayMs, maxDelayMs, retryableStatuses } = {
    ...defaultRetryConfig,
    ...config
  };
  
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      console.log(`API call attempt ${attempt + 1}/${maxRetries + 1}`);
      
      const response = await fetch(url, options);
      
      // Se não é um status retryable, retorna (sucesso ou erro definitivo)
      if (!retryableStatuses.includes(response.status)) {
        return response;
      }
      
      // Status retryable - fazer retry se ainda temos tentativas
      if (attempt < maxRetries) {
        const delay = Math.min(initialDelayMs * Math.pow(2, attempt), maxDelayMs);
        console.log(`Retryable status ${response.status}, waiting ${delay}ms before retry...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      
      // Última tentativa falhou
      return response;
      
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      
      // Erro de rede - fazer retry se ainda temos tentativas
      if (attempt < maxRetries) {
        const delay = Math.min(initialDelayMs * Math.pow(2, attempt), maxDelayMs);
        console.log(`Network error: ${lastError.message}, waiting ${delay}ms before retry...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
    }
  }
  
  throw lastError || new Error('All retry attempts failed');
}

// Check if extracted text is readable (not binary garbage)
function isTextReadable(text: string): boolean {
  if (!text || text.length < 100) return false;
  
  // Count real words (sequences of 3+ letters)
  const words = text.match(/[a-zA-ZÀ-ÿ]{3,}/g) || [];
  console.log(`Text analysis: ${words.length} words found, text length: ${text.length}`);
  
  if (words.length < 20) {
    console.log('Rejected: Less than 20 words found');
    return false;
  }
  
  // Check for common patterns in Brazilian documents
  const hasCommonPatterns = /\b(CPF|CNPJ|R\$|Nome|Data|Valor|Contrato|Grupo|Cota|Cliente|Parcela|Saldo|Crédito|Administradora)\b/i.test(text);
  
  // Count control and binary characters
  const binaryChars = text.match(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]/g) || [];
  const binaryRatio = binaryChars.length / text.length;
  console.log(`Binary ratio: ${(binaryRatio * 100).toFixed(2)}%`);
  
  // Dynamic threshold: if we have lots of valid words, allow more binary noise
  // Encrypted PDFs often have binary metadata mixed with readable text
  const binaryThreshold = words.length >= 100 ? 0.20 : (words.length >= 50 ? 0.10 : 0.05);
  
  if (binaryRatio > binaryThreshold) {
    console.log(`Rejected: Binary ratio ${(binaryRatio * 100).toFixed(2)}% exceeds threshold ${(binaryThreshold * 100).toFixed(0)}%`);
    return false;
  }
  
  console.log(`Binary ratio ${(binaryRatio * 100).toFixed(2)}% within threshold ${(binaryThreshold * 100).toFixed(0)}% (${words.length} words found)`);
  
  // Check proportion of readable ASCII characters
  const readableChars = text.match(/[\x20-\x7E]/g) || [];
  const readableRatio = readableChars.length / text.length;
  console.log(`Readable ASCII ratio: ${(readableRatio * 100).toFixed(2)}%`);
  
  // Flexible validation for PDFs with compressed/encrypted content:
  // 1. 30%+ ASCII with 200+ words (enough content to attempt AI structuring even without pattern match)
  // 2. 30%+ ASCII with 100+ words AND common Brazilian doc patterns
  // 3. 50%+ ASCII with 50+ words OR common patterns
  const isValid = (readableRatio > 0.3 && words.length >= 200) ||
                  (readableRatio > 0.3 && words.length >= 100 && hasCommonPatterns) || 
                  (readableRatio > 0.5 && (words.length >= 50 || hasCommonPatterns));
  console.log(`Text readable: ${isValid}, hasCommonPatterns: ${hasCommonPatterns}`);
  
  return isValid;
}

// Validate extracted content before returning
function validateExtractedContent(content: Record<string, string>): { valid: boolean; reason?: string; cleaned?: boolean } {
  const allText = Object.values(content).join(' ');
  
  if (!allText || allText.length < 50) {
    return { valid: false, reason: 'Content too short or empty' };
  }
  
  // Check if it contains real words
  const wordCount = (allText.match(/[a-zA-ZÀ-ÿ]{3,}/g) || []).length;
  
  // Check for absence of binary patterns
  const binaryPatternMatch = allText.match(/[\x00-\x08\x0B\x0E-\x1F]/g) || [];
  const hasBinaryPatterns = binaryPatternMatch.length > 0;
  
  // Check for excessive special characters (corrupted PDF)
  const specialChars = allText.match(/[^\x20-\x7EÀ-ÿ\n\r\t]/g) || [];
  const specialRatio = specialChars.length / allText.length;
  
  console.log(`Content validation: ${wordCount} words, hasBinaryPatterns: ${hasBinaryPatterns}, specialRatio: ${(specialRatio * 100).toFixed(2)}%`);
  
  if (wordCount < 30) {
    return { valid: false, reason: `Insufficient readable words (found ${wordCount}, need 30+)` };
  }
  
  // For content with enough words (200+), tolerate binary noise — the AI model can handle it
  // This is common in encrypted PDFs with soft security (no password required to open)
  if (wordCount >= 200 && specialRatio < 0.5) {
    if (hasBinaryPatterns || specialRatio > 0.3) {
      console.log(`Content has noise but enough words (${wordCount}) - marking for cleaning`);
      return { valid: true, cleaned: true };
    }
  }
  
  if (hasBinaryPatterns) {
    return { valid: false, reason: 'Content contains binary/control characters' };
  }
  
  if (specialRatio > 0.3) {
    return { valid: false, reason: `Too many special/unreadable characters (${(specialRatio * 100).toFixed(1)}%)` };
  }
  
  return { valid: true };
}

// Extract PDF from multipart response using binary search for %PDF and %%EOF signatures
function extractPdfFromMultipart(buffer: ArrayBuffer): ArrayBuffer | null {
  const uint8 = new Uint8Array(buffer);
  
  // Find %PDF signature in the buffer
  const pdfSignature = [0x25, 0x50, 0x44, 0x46]; // %PDF
  
  for (let i = 0; i < uint8.length - 4; i++) {
    if (uint8[i] === pdfSignature[0] &&
        uint8[i+1] === pdfSignature[1] &&
        uint8[i+2] === pdfSignature[2] &&
        uint8[i+3] === pdfSignature[3]) {
      
      // Found PDF start, now find the end (%%EOF)
      const eofSignature = [0x25, 0x25, 0x45, 0x4F, 0x46]; // %%EOF
      
      for (let j = uint8.length - 5; j > i; j--) {
        if (uint8[j] === eofSignature[0] &&
            uint8[j+1] === eofSignature[1] &&
            uint8[j+2] === eofSignature[2] &&
            uint8[j+3] === eofSignature[3] &&
            uint8[j+4] === eofSignature[4]) {
          
          // Extract from %PDF to %%EOF + possible trailing bytes (newlines)
          // Include up to 2 extra bytes for \r\n after %%EOF
          const endIndex = Math.min(j + 7, uint8.length);
          console.log(`Found PDF in multipart: start=${i}, end=${j}, extracting ${endIndex - i} bytes`);
          return buffer.slice(i, endIndex);
        }
      }
      
      // If no %%EOF found but we found %PDF, try to extract from %PDF to end minus boundary
      console.log('No %%EOF found, extracting from %PDF to near end of buffer');
      // Look for closing boundary (usually "--boundary--" or similar)
      for (let j = uint8.length - 10; j > i; j--) {
        if (uint8[j] === 0x2D && uint8[j+1] === 0x2D) { // "--"
          return buffer.slice(i, j);
        }
      }
    }
  }
  
  return null;
}

// Check if PDF is encrypted with password protection
// Returns false for PDFs that are "encrypted" but have empty/no password (still readable)
function isPDFEncrypted(pdfBuffer: ArrayBuffer): { encrypted: boolean; hasRealPassword: boolean } {
  const bytes = new Uint8Array(pdfBuffer);
  const text = new TextDecoder('latin1').decode(bytes);
  
  // Look for /Encrypt in trailer dictionary context (indicates some encryption)
  const hasEncryptInTrailer = /\/Encrypt\s+\d+\s+\d+\s+R/.test(text);
  const hasEncryptKey = /\/Encrypt\s*<</.test(text);
  const hasEncryption = hasEncryptInTrailer || hasEncryptKey;
  
  if (!hasEncryption) {
    return { encrypted: false, hasRealPassword: false };
  }
  
  // Check if it's password-protected vs just "encrypted" with empty password
  // PDFs with /U and /O entries that are all 0x00 or empty have no real password
  // Also check for /P permissions which indicate encryption level
  const hasUserPassword = /\/U\s*\(/.test(text) || /\/U\s*<[^>]+>/.test(text);
  const hasOwnerPassword = /\/O\s*\(/.test(text) || /\/O\s*<[^>]+>/.test(text);
  
  // If no password entries found, treat as unencrypted
  if (!hasUserPassword && !hasOwnerPassword) {
    console.log('PDF has encryption markers but no password entries - treating as readable');
    return { encrypted: true, hasRealPassword: false };
  }
  
  console.log('PDF encryption detected with password entries');
  return { encrypted: true, hasRealPassword: true };
}

// Simple PDF text extraction (for uncompressed PDFs)
function extractTextFromPDF(pdfBuffer: ArrayBuffer): { pages: string[], pageCount: number, isReadable: boolean } {
  const bytes = new Uint8Array(pdfBuffer);
  const text = new TextDecoder('latin1').decode(bytes);
  
  const streamRegex = /stream\s*([\s\S]*?)\s*endstream/g;
  const textContentRegex = /\(([^)]*)\)/g;
  const tjRegex = /\[(.*?)\]\s*TJ/g;
  
  const pages: string[] = [];
  let currentPageText = '';
  let pageCount = 0;
  
  const pageMatches = text.match(/\/Type\s*\/Page[^s]/g);
  pageCount = pageMatches ? pageMatches.length : 1;
  
  let streamMatch;
  while ((streamMatch = streamRegex.exec(text)) !== null) {
    const streamContent = streamMatch[1];
    let decodedContent = streamContent;
    
    let textMatch;
    while ((textMatch = textContentRegex.exec(decodedContent)) !== null) {
      const extracted = textMatch[1]
        .replace(/\\n/g, '\n')
        .replace(/\\r/g, '')
        .replace(/\\t/g, ' ')
        .replace(/\\\(/g, '(')
        .replace(/\\\)/g, ')')
        .replace(/\\\\/g, '\\');
      if (extracted.trim()) {
        currentPageText += extracted + ' ';
      }
    }
    
    while ((textMatch = tjRegex.exec(decodedContent)) !== null) {
      const tjContent = textMatch[1];
      const textParts = tjContent.match(/\(([^)]*)\)/g);
      if (textParts) {
        for (const part of textParts) {
          const cleaned = part.slice(1, -1)
            .replace(/\\n/g, '\n')
            .replace(/\\r/g, '')
            .replace(/\\t/g, ' ');
          if (cleaned.trim()) {
            currentPageText += cleaned;
          }
        }
        currentPageText += ' ';
      }
    }
  }
  
  const isReadable = isTextReadable(currentPageText);
  
  if (currentPageText.trim() && isReadable) {
    const words = currentPageText.split(/\s+/).filter(w => w.length > 0);
    const wordsPerPage = Math.ceil(words.length / Math.max(pageCount, 1));
    
    for (let i = 0; i < pageCount; i++) {
      const start = i * wordsPerPage;
      const end = Math.min(start + wordsPerPage, words.length);
      const pageWords = words.slice(start, end);
      pages.push(pageWords.join(' '));
    }
  }
  
  return { pages, pageCount: Math.max(pageCount, 1), isReadable };
}

// Extract text using Vision API (Gemini 2.5 Pro)
async function extractWithVisionAPI(pdfBuffer: ArrayBuffer, apiKey: string): Promise<{ text: string, pageCount: number }> {
  console.log('Using Vision API for PDF extraction...');
  
  // Convert PDF to base64 - must encode all bytes at once for valid base64
  const bytes = new Uint8Array(pdfBuffer);
  let binaryString = '';
  for (let i = 0; i < bytes.length; i++) {
    binaryString += String.fromCharCode(bytes[i]);
  }
  const base64Pdf = btoa(binaryString);
  
  const response = await fetchWithRetry('https://ai.gateway.lovable.dev/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'google/gemini-2.5-flash',
      messages: [
        {
          role: 'system',
          content: `Você é um especialista em OCR de documentos financeiros brasileiros (extratos de consórcio, faturas, demonstrativos).
Sua tarefa é extrair TODO o texto visível do documento PDF, otimizado para tabelas financeiras.

REGRAS CRÍTICAS:
1. Preserve o ALINHAMENTO de colunas em tabelas usando espaços ou tabs consistentes.
2. Identifique e mantenha CABEÇALHOS de tabela na linha imediatamente acima dos dados.
3. Separe SEÇÕES com labels claros (ex: "=== Pagamentos Realizados ===").
4. Mantenha valores monetários INTACTOS em uma única linha (ex: "R$ 1.234,56" — nunca quebre).
5. Preserve datas no formato original (DD/MM/YYYY).
6. Preserve CPF/CNPJ no formato original com pontuação.
7. Não adicione interpretações nem resumos — apenas extraia o texto fiel ao documento.
8. Para campos rotulados (label: valor), mantenha label e valor na mesma linha sempre que possível.`
        },
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: 'Extraia todo o texto deste documento PDF. Formate a saída assim:\n\n--- PÁGINA 1 ---\n[texto da página 1]\n\n--- PÁGINA 2 ---\n[texto da página 2]\n\nE assim por diante.'
            },
            {
              type: 'image_url',
              image_url: {
                url: `data:application/pdf;base64,${base64Pdf}`
              }
            }
          ]
        }
      ],
      temperature: 0.1,
      max_tokens: 32000,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Vision API error:', response.status, errorText);
    throw new Error(`Vision API failed: ${response.status}`);
  }

  const data = await response.json();
  const extractedText = data.choices?.[0]?.message?.content || '';
  
  // Count pages from the extracted text
  const pageMatches = extractedText.match(/---\s*PÁGINA\s*\d+\s*---/gi);
  const pageCount = pageMatches ? pageMatches.length : 1;
  
  console.log(`Vision API extracted ${extractedText.length} chars, ${pageCount} pages`);
  
  return { text: extractedText, pageCount };
}

// =====================================================================
// Post-processing normalization helpers
// =====================================================================

const ADMIN_ALIASES: Record<string, string> = {
  'embracon': 'EMBRACON',
  'caixa': 'CAIXA',
  'xs5': 'CAIXA',
  'porto seguro': 'PORTO SEGURO',
  'porto': 'PORTO SEGURO',
  'rodobens': 'RODOBENS',
  'bradesco': 'BRADESCO',
  'itau': 'ITAU',
  'itaú': 'ITAU',
  'santander': 'SANTANDER',
  'banco do brasil': 'BANCO DO BRASIL',
  'bb consorcio': 'BANCO DO BRASIL',
  'bb consórcio': 'BANCO DO BRASIL',
  'volkswagen': 'VOLKSWAGEN',
  'vw': 'VOLKSWAGEN',
  'mycon': 'MYCON',
  'coimex': 'MYCON',
};

function normalizeCPF(value: unknown): unknown {
  if (typeof value !== 'string') return value;
  // remove qualquer texto não-CPF/CNPJ colado (ex: "168.410.987-65AUTOM")
  const cpfMatch = value.match(/(\d{3}\.\d{3}\.\d{3}-\d{2})/);
  if (cpfMatch) return cpfMatch[1];
  const cnpjMatch = value.match(/(\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2})/);
  if (cnpjMatch) return cnpjMatch[1];
  // só dígitos -> formatar se tiver 11 ou 14
  const digits = value.replace(/\D/g, '');
  if (digits.length === 11) {
    return `${digits.slice(0,3)}.${digits.slice(3,6)}.${digits.slice(6,9)}-${digits.slice(9)}`;
  }
  if (digits.length === 14) {
    return `${digits.slice(0,2)}.${digits.slice(2,5)}.${digits.slice(5,8)}/${digits.slice(8,12)}-${digits.slice(12)}`;
  }
  return value;
}

function normalizeDate(value: unknown): unknown {
  if (typeof value !== 'string') return value;
  const trimmed = value.trim();
  // já em ISO
  if (/^\d{4}-\d{2}-\d{2}/.test(trimmed)) return trimmed.slice(0, 10);
  // DD/MM/YYYY ou DD-MM-YYYY
  const m = trimmed.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/);
  if (m) {
    let [, d, mo, y] = m;
    if (y.length === 2) y = (parseInt(y) > 50 ? '19' : '20') + y;
    return `${y}-${mo.padStart(2,'0')}-${d.padStart(2,'0')}`;
  }
  return value;
}

function normalizeMoney(value: unknown): unknown {
  if (typeof value === 'number') return value;
  if (typeof value !== 'string') return value;
  const cleaned = value
    .replace(/R\$\s*/gi, '')
    .replace(/\s/g, '')
    .trim();
  if (!cleaned) return value;
  // formato BR: 1.234,56 -> 1234.56
  if (/^-?[\d.]+,\d{1,2}$/.test(cleaned)) {
    const n = parseFloat(cleaned.replace(/\./g, '').replace(',', '.'));
    return isNaN(n) ? value : n;
  }
  // já decimal puro
  if (/^-?\d+(\.\d+)?$/.test(cleaned)) {
    const n = parseFloat(cleaned);
    return isNaN(n) ? value : n;
  }
  return value;
}

function normalizeAdmin(value: unknown): unknown {
  if (typeof value !== 'string') return value;
  const lower = value.toLowerCase().trim();
  for (const [key, canonical] of Object.entries(ADMIN_ALIASES)) {
    if (lower.includes(key)) return canonical;
  }
  return value;
}

const DATE_KEYS = new Set([
  'data_adesao', 'data_venda', 'data_contemplacao', 'data_pagamento',
  'primeira_assembleia', 'ultima_assembleia', 'encerramento',
  'ultimo_reajuste', 'ultimo_vencimento_cota', 'vencimento', 'nascimento'
]);
const MONEY_KEY_RE = /(valor|saldo|credito|crédito|total|fundo|taxa|multa|juros|seguro|parcela|bem|liquido|líquido|original|corrigido|pago|pagar|antecipado|reserva|administracao|administração|outros|rateio)/i;

function walkNormalize(obj: unknown): unknown {
  if (Array.isArray(obj)) return obj.map(walkNormalize);
  if (obj && typeof obj === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj as Record<string, unknown>)) {
      const lk = k.toLowerCase();
      if (lk === 'cpf' || lk === 'cnpj' || lk === 'cpf_cnpj') {
        out[k] = normalizeCPF(v);
      } else if (lk === 'administradora') {
        out[k] = normalizeAdmin(v);
      } else if (DATE_KEYS.has(lk) || lk.startsWith('data_') || lk.endsWith('_data')) {
        out[k] = typeof v === 'string' ? normalizeDate(v) : walkNormalize(v);
      } else if (typeof v === 'string' && MONEY_KEY_RE.test(lk) && !lk.includes('percentual') && !lk.includes('numero') && !lk.includes('tipo')) {
        out[k] = normalizeMoney(v);
      } else if (v && typeof v === 'object') {
        out[k] = walkNormalize(v);
      } else {
        out[k] = v;
      }
    }
    return out;
  }
  return obj;
}

function normalizeStructuredData(parsed: Record<string, unknown>): Record<string, unknown> {
  const normalized = walkNormalize(parsed) as Record<string, unknown>;

  // Cross-field fallback: meses_pagos / meses_a_pagar a partir de resumo_financeiro
  const dp = normalized.dados_plano as Record<string, unknown> | undefined;
  const rf = normalized.resumo_financeiro as Record<string, unknown> | undefined;
  if (dp && rf) {
    if (dp.meses_pagos == null && rf.parcelas_pagas != null) dp.meses_pagos = rf.parcelas_pagas;
    if (dp.meses_a_pagar == null && rf.parcelas_restantes != null) dp.meses_a_pagar = rf.parcelas_restantes;
    if (dp.prazo_grupo_meses == null && typeof dp.meses_pagos === 'number' && typeof dp.meses_a_pagar === 'number') {
      dp.prazo_grupo_meses = (dp.meses_pagos as number) + (dp.meses_a_pagar as number);
    }
  }
  return normalized;
}

// Structure financial document with specialized prompt
async function structureFinancialDocument(rawText: string, fileName: string, apiKey: string): Promise<{
  dados_cadastrais: Record<string, unknown>;
  dados_plano: Record<string, unknown>;
  contemplacao: Record<string, unknown>;
  resumo_financeiro: Record<string, unknown>;
  pendencias: Record<string, unknown>;
  confidence: number;
}> {
  console.log('Structuring financial document with Gemini 2.5 Pro...');
  
  const systemPrompt = `Você é um especialista em análise de documentos financeiros brasileiros, especialmente documentos de consórcio.

TAREFA: Analise o documento e extraia informações estruturadas com alta precisão.

ADMINISTRADORAS RECONHECIDAS:
- EMBRACON ADMINISTRADORA DE CONSORCIO S/A (ou "EMBRACON")
- CAIXA CONSORCIO / XS5 ADMª DE CONSORCIO S/A (ou "CAIXA")
- PORTO SEGURO
- RODOBENS
- BRADESCO
- ITAÚ CONSÓRCIO (ou "ITAÚ", "ITAU")
- SANTANDER
- BANCO DO BRASIL CONSÓRCIOS (ou "BB CONSÓRCIO", "BB", "BANCO DO BRASIL")

REGRAS DE FORMATAÇÃO:
1. CPF: formato XXX.XXX.XXX-XX (formatar mesmo se vier sem pontuação)
2. CNPJ: formato XX.XXX.XXX/XXXX-XX
3. Datas: formato YYYY-MM-DD (ISO 8601)
4. Valores monetários: número decimal (ex: 40573.82, não "R$ 40.573,82")
5. Percentuais: número decimal (ex: 18.5 para 18,5%)
6. Telefones: apenas números, sem formatação

ESTRATÉGIA DE EXTRAÇÃO (ordem de prioridade):
1. Tente identificar a administradora pelo cabeçalho/rodapé do documento.
2. Se reconhecida, aplique as REGRAS ESPECÍFICAS POR ADMINISTRADORA abaixo (são DICAS, não único caminho).
3. Se NÃO reconhecida, use o BLOCO GENÉRICO + SINÔNIMOS abaixo para mapear semanticamente.
4. Em qualquer caso, prefira valores explícitos do documento; só calcule quando o campo não existir.

ADMINISTRADORA NÃO RECONHECIDA (BLOCO GENÉRICO):
- Buscar nome da administradora no cabeçalho, rodapé ou marca d'água do documento.
- Mapear campos por proximidade semântica usando a tabela de SINÔNIMOS abaixo.
- Tabelas com colunas tipo "Vencimento", "Valor", "Pago" -> lista de parcelas.
- Qualquer string no formato XXX.XXX.XXX-XX -> dados_cadastrais.cpf.
- Qualquer string no formato XX.XXX.XXX/XXXX-XX -> dados_cadastrais.cnpj.
- Qualquer data DD/MM/YYYY ou DD-MM-YYYY -> converter para YYYY-MM-DD.
- Seções com totalizadores "Total Pago"/"Saldo Devedor" -> resumo_financeiro.
- Se um campo aparecer várias vezes, prefira o da seção mais específica (ex: "Resumo da Cota").

SINÔNIMOS DE CAMPOS (use para mapear independentemente da administradora):
- valor_credito: "Valor do Crédito", "Valor Atualizado da Carta", "Carta de Crédito", "Valor do Bem", "Crédito", "Crédito Atualizado"
- grupo: "Grupo", "Nº Grupo", "Grupo Nº", "Nº do Grupo"
- cota: "Cota", "Nº Cota", "Cota Nº", "Nº da Cota"
- contrato: "Contrato", "Proposta", "Nº Contrato", "Nº Proposta", "Contrato Nº"
- data_adesao: "Data Adesão", "Data de Adesão", "Data Contratação", "Dt. Adesão", "Data de Contratação"
- meses_pagos: "Parcelas Pagas", "Qtde Pagas", "Nº Parcelas Pagas", "Parcelas Quitadas"
- meses_a_pagar: "Parcelas Restantes", "Qtde a Pagar", "Parcelas a Pagar", "Parcelas Pendentes"
- prazo_grupo_meses: "Prazo do Grupo", "Prazo Total", "Duração do Grupo"
- total_pago: "Total Pago", "Valores Pagos", "TOTAL" (na seção de pagos)
- saldo_devedor: "Saldo Devedor", "Total a Pagar", "TOTAL" (na seção a pagar)
- taxa_administracao: "Taxa de Administração", "Tx. Adm.", "Taxa Adm"
- fundo_reserva: "Fundo de Reserva", "F. Reserva", "Fdo Reserva"
- assembleia_atual: "Assembleia Atual", "Próxima Assembleia", "Assembleia Nº"
- sit_cobranca: "Situação da Cota", "Sit. Cobrança", "Status", "Situação"

REGRAS ESPECÍFICAS POR ADMINISTRADORA (dicas adicionais):

CAIXA CONSÓRCIO:
- O campo "Bem" contém código + descrição (ex: "IMO200 IMO - CRÉDITO R$ 200 Mil")
  - Extrair descrição completa para "bem"
  - Código (ex: "IMO200") indica tipo
- "Produto" indica categoria (ex: "IMO IMOBILIARIO") - normalizar para tipo padrão
- "SubProduto" contém código e nome (ex: "000001 IMÓVEIS")
  - Código vai para "codigo_produto"
  - Nome vai para "subproduto"
- "Tipo de Venda" vai para "tipo_venda" (ex: COM LANCE EMBUTIDO)
- "Pessoa" indica tipo_pessoa (Física ou Jurídica)
- "1ª Assembleia" pode ter número da assembleia entre parênteses
- "Assembleia Atual" indica próxima assembleia - extrair para assembleia_atual
- "Sit. Cobrança" vai para "sit_cobranca"
- "Último Reajuste" vai para "ultimo_reajuste"
- Seção "Valores / Percentuais Pagos" = resumo_financeiro.valores_pagos
- Seção "Valores / Percentuais a Pagar" = resumo_financeiro.valores_a_pagar
- "Qtde Total" em "Resumo Parcelas Pagas" = parcelas_pagas
- "Qtde Total" em "Resumo Parcelas a Pagar" = parcelas_restantes
- "% Antecipado" vai para percentual_antecipado
- "Ideal Pago" vai para ideal_pago

ITAÚ CONSÓRCIO:
- Identificar por "ITAÚ ADMINISTRADORA DE CONSÓRCIO LTDA" no cabeçalho
- Normalizar administradora para "ITAU"
- Cabeçalho: Grupo, Cota (número antes do nome), Nome do consorciado (após número da cota)
- "Contrato" -> dados_plano.contrato
- "Data venda" -> dados_plano.data_venda
- "Data Adesão" -> dados_plano.data_adesao
- "1ª assembleia" -> dados_plano.primeira_assembleia (extrair data e número)
- "Plano básico" -> dados_plano.prazo_basico_meses
- "Prazo do grupo" -> dados_plano.prazo_grupo_meses
- "Taxa adm." -> dados_plano.taxa_administracao (valor percentual, ex: 30.0)
- "Fundo reserva" -> dados_plano.fundo_reserva (valor percentual, ex: 2.0)
- "Produto" -> dados_plano.produto (código numérico para codigo_produto, nome para produto)
  - Normalizar: "IMÓVEIS" -> "IMOVEL", "AUTOMÓVEIS" -> "AUTOMOVEL"
- "SubProduto" -> dados_plano.subproduto e dados_plano.codigo_produto
- "Tipo de venda" -> dados_plano.tipo_venda
- "Assemb. Atual" -> dados_plano.assembleia_atual (objeto com data e número)
- "Sit. de cobrança" -> dados_plano.sit_cobranca
- "Bem" -> dados_plano.bem (código + descrição, ex: "IMOVEL PADRAO 50 MIL")
- "Valor crédito" -> dados_plano.valor_credito
- "Último reajuste em" -> dados_plano.ultimo_reajuste
- "Próximo reajuste em" -> dados_plano.proximo_reajuste
- "Data prevista para o encerramento" -> dados_plano.encerramento
- "Valor contribuição mensal" -> dados_plano.valor_parcela_atual
- Seção "Contemplação":
  - "Dt.contemplação" -> contemplacao.data_contemplacao
  - "Crédito" -> contemplacao.credito_original
  - "Tipo contempl." -> contemplacao.tipo (Sorteio, Lance)
  - "Créd. corrig." -> contemplacao.credito_corrigido
  - "Valor bem entregue" -> contemplacao.valor_bem_entregue
  - "Líquido a pagar" -> contemplacao.valor_liquido
- Seção "Percentuais" (tabela):
  - "% normal" linha "Pago" -> resumo_financeiro.total_pago_percentual
  - "% antecipado" linha "Pago" -> resumo_financeiro.percentual_antecipado
  - "Ideal pago" -> resumo_financeiro.ideal_pago
- Seção "Conta Corrente" (tabela de parcelas):
  - Contar linhas = parcelas pagas (meses_pagos)
  - Cada linha tem: assembleia, vencimento, pagamento, valor devido, valor pago, multa, juros, seguro, % pago
  - TOTAIS no final = somatórios
- Seção "Pendência":
  - Primeira linha = pendencias.proxima_parcela
    - Ass. (número) -> numero
    - Vencto. -> vencimento
    - Vl. parcela -> valor
- Seção "Valores/Percentuais pagos" (Página 2):
  - Fundo comum: valor + percentual -> resumo_financeiro.valores_pagos.fundo_comum / fundo_comum_percentual
  - Fundo de Reserva: valor + percentual -> resumo_financeiro.valores_pagos.fundo_reserva / fundo_reserva_percentual
  - Taxa de Administração: valor + percentual -> resumo_financeiro.valores_pagos.taxa_administracao / taxa_administracao_percentual
  - Adesão: valor -> resumo_financeiro.valores_pagos.adesao
  - Seguros: valor -> resumo_financeiro.valores_pagos.seguros
  - Multas: valor -> resumo_financeiro.valores_pagos.multas
  - Juros: valor -> resumo_financeiro.valores_pagos.juros
  - TOTAL: valor + percentual -> resumo_financeiro.valores_pagos.total_pago
- Seção "Valores/Percentuais a pagar" (Página 2):
  - Mesma estrutura acima -> resumo_financeiro.valores_a_pagar
  - TOTAL -> resumo_financeiro.valores_a_pagar.total
- Seção "Resumo Parcelas Pagas" (Página 2):
  - "Qtde Total" -> dados_plano.meses_pagos (confirmar com contagem da Conta Corrente)
  - parcelas_restantes = Qtde Total de "Resumo Parcelas a Pagar"
- CPF: extrair do nome/cota se disponível (pode não estar no extrato Itaú)
- meses_a_pagar = prazo_grupo - meses_pagos

EMBRACON:
- O campo "Produto" no documento (ex: "IMOVEIS", "AUTOMOVEL") deve ser usado como base para:
  - "produto": normalizar para tipo padrão (IMOVEL, AUTOMOVEL, SERVICO, MOTO, CAMINHAO)
  - "bem": usar a descrição completa do crédito (ex: "CREDITO 150.000 MIL" ou o valor do campo produto)
- O código entre parênteses (ex: "000014") vai para "codigo_produto"

VOLKSWAGEN CONSÓRCIO:
- Identificar por "CONSÓRCIO NACIONAL VOLKSWAGEN ADMINISTRADORA DE CONSÓRCIO LTDA"
- Normalizar administradora para "VOLKSWAGEN"
- Cabeçalho: Grupo, Cota (número com sufixo -00, manter só o número), Nome completo, Contrato
- Dados Cadastrais completos:
  - "Pessoa" -> dados_cadastrais.tipo_pessoa (Física/Jurídica)
  - "CPF/CNPJ" -> dados_cadastrais.cpf (formatar com pontuação)
  - "Data Nascimento" -> dados_cadastrais.data_nascimento (formato ISO)
  - "Profissão" -> dados_cadastrais.profissao
  - "Documento" -> dados_cadastrais.documento_rg
  - Endereço completo: rua, número, complemento, bairro, cidade, UF, CEP -> dados_cadastrais.endereco (concatenar tudo)
  - "Telefone" -> dados_cadastrais.telefone
- Dados do Plano:
  - "Data Venda" -> dados_plano.data_venda
  - "Data Adesão" -> dados_plano.data_adesao
  - "1ª Assembléia" -> dados_plano.primeira_assembleia (data + número)
  - "Plano Básico" (meses) -> dados_plano.prazo_basico_meses
  - "Prazo do grupo" (meses) -> dados_plano.prazo_grupo_meses
  - "Produto" -> dados_plano.produto (normalizar AUTOMÓVEIS->AUTOMOVEL, usar descrição sem código)
  - "Taxa Adm" -> dados_plano.taxa_administracao (percentual numérico)
  - "Fundo Reserva" -> dados_plano.fundo_reserva (percentual numérico)
  - "Último/Próximo reajuste" -> dados_plano.ultimo_reajuste / proximo_reajuste
  - "% Cob. Contemp" -> dados_plano.percentual_cobertura_contemplacao
- Assembléia Atual: data, número, vencimento, local -> dados_plano.assembleia_atual (objeto)
- Representante/Vendedor: ignorar (não mapeado no schema)
- Bem: código + descrição -> dados_plano.bem (ex: "AUTOMOVEL 100.000"), Valor Crédito -> dados_plano.valor_credito
- Encerramento: data prevista -> dados_plano.encerramento
- "Data último vencimento da cota" -> dados_plano.ultimo_vencimento_cota
- "Valor Contrib. Mensal" (na tabela Percentuais) -> dados_plano.valor_parcela_atual
- Contemplação:
  - "Dt. Contemplação" -> contemplacao.data_contemplacao
  - "Crédito" -> contemplacao.credito_original
  - "Tipo Contempl." -> contemplacao.tipo (ex: "Lance 68 pcls." -> tipo="Lance", parcelas_lance=68; "Sorteio" -> tipo="Sorteio")
  - "Crédito Corrigido" -> contemplacao.credito_corrigido
  - "Valor Bem Entregue" -> contemplacao.valor_bem_entregue
  - "Líquido a Pagar" -> contemplacao.valor_liquido
- Percentuais (tabela na Página 1):
  - "% Normal" coluna Pago -> resumo_financeiro.total_pago_percentual
  - "% Antecipado" coluna Pago -> resumo_financeiro.percentual_antecipado
  - "Ideal Pago" -> resumo_financeiro.ideal_pago
  - "Mensal" -> dados_plano.percentual_mensal
- Conta Corrente:
  - Contar linhas com transação "RECBTO. PARCELA" = parcelas normais pagas (meses_pagos)
  - Linhas "RECBTO. LANCE" / "LANCE EMBUTIDO" = lances (NÃO contar como parcelas normais)
  - Linhas "PAGTO BEM" / "TAXA DE CADASTRO" = movimentações especiais (ignorar na contagem)
- Pendência -> pendencias.proxima_parcela (Ass.=numero, Vencto.=vencimento, Vl. Parcela=valor)
- Página 2 - Valores/Percentuais Pagos -> resumo_financeiro.valores_pagos (mesma estrutura Itaú/Embracon: fundo_comum, fundo_reserva, taxa_administracao, adesao, seguros, multas, juros, total_pago + percentuais)
- Página 2 - Valores/Percentuais a Pagar -> resumo_financeiro.valores_a_pagar (mesma estrutura)
- "Resumo Parcelas a Pagar" Qtde Total -> dados_plano.meses_a_pagar
- meses_pagos = prazo_grupo - meses_a_pagar (ou contar RECBTO. PARCELA na Conta Corrente)

MYCON / COIMEX ADM. CONSÓRCIOS:
- Identificar por "COIMEX ADM. CONSÓRCIOS S.A" no cabeçalho (campo EMPRESA)
- Normalizar administradora: SEMPRE usar "MYCON" como valor de dados_plano.administradora para qualquer extrato COIMEX, independentemente do conteúdo do campo REPRESENTANTE
  (ex: "026007 MYCON" -> administradora="MYCON"; campo ausente ou diferente -> ainda usar "MYCON")
- Cabeçalho: GRUPO, COTA (manter número antes do traço, ex: "0337-00" -> cota="0337"), CONTRATO, NOME
- Dados Cadastrais:
  - "CNPJ/CPF" -> dados_cadastrais.cpf (formatar com pontuação: xxx.xxx.xxx-xx para CPF)
  - "PESSOA" -> dados_cadastrais.tipo_pessoa (ex: "Física" ou "Jurídica")
  - "DOCUMENTO" -> dados_cadastrais.documento_rg
  - "ENDEREÇO" + número, COMPLEMENTO, BAIRRO, CIDADE, ESTADO, CEP -> dados_cadastrais.endereco (objeto concatenado)
  - "TELEFONE" ou "CELULAR" -> dados_cadastrais.telefone (preferir CELULAR se ambos presentes)
  - "DATA NASCIMENTO" -> dados_cadastrais.data_nascimento
  - "PROFISSÃO" -> dados_cadastrais.profissao
- Dados do Plano:
  - "DATA ADESÃO" -> dados_plano.data_adesao
  - "BEM BÁSICO" -> linha com formato "CÓDIGO TIPO R$ VALOR" (ex: "1657 IMOVEL R$ 315.029,59"):
    - Código numérico inicial -> dados_plano.codigo_produto (ex: "1657")
    - Tipo do bem -> dados_plano.produto (normalizar: IMOVEL, AUTOMOVEL, MOTO, CAMINHAO, SERVICO) e dados_plano.bem
    - Valor monetário -> dados_plano.valor_credito (numérico, sem R$)
  - "PLANO BÁSICO" (ex: "240 meses") -> dados_plano.prazo_basico_meses E dados_plano.prazo_grupo_meses (usar o mesmo valor pois não há prazo do grupo separado)
  - "SIT. DA COTA" (ex: "10/02/2026 - NORMAL") -> extrair status após o traço -> dados_plano.sit_cobranca (ex: "NORMAL")
  - "TAXA ADM." -> dados_plano.taxa_administracao (numérico, ex: 9.99)
  - "FDO. RESERVA" -> dados_plano.fundo_reserva (numérico, pode ser 0.00)
  - "PERCENTUAL MENSAL" -> dados_plano.percentual_mensal
  - "1ª ASSEMBLEIA" -> dados_plano.primeira_assembleia
  - "CONTRIBUIÇÃO MENSAL" -> dados_plano.valor_parcela_atual (numérico, sem R$)
- Contemplação (seção específica no documento):
  - "DATA DA CONTEMPLAÇÃO" -> contemplacao.data_contemplacao
  - "TIPO DE CONTEMPLAÇÃO" -> contemplacao.tipo (ex: "SORTEIO" ou "LANCE")
  - "VALOR CRÉDITO" (na seção Contemplação) -> contemplacao.credito_original (numérico)
  - "VALOR CORRIGIDO" -> contemplacao.credito_corrigido (numérico)
  - "VALOR ENTREGUE" -> contemplacao.valor_bem_entregue (numérico)
  - "LIQ. A PAGAR" -> contemplacao.valor_liquido (numérico)
- Parcelas:
  - "QTDE. DE PARCELAS" primeiro bloco (pagas) -> dados_plano.meses_pagos (inteiro)
  - "QTDE. DE PARCELAS" segundo bloco (a pagar) -> dados_plano.meses_a_pagar (inteiro)
  - "% DO BEM OBJETO" primeiro bloco (pago) -> resumo_financeiro.total_pago_percentual
- Percentuais (tabela PERCENTUAIS com colunas PAGO / A PAGAR):
  - "% NORMAL" coluna PAGO -> resumo_financeiro.total_pago_percentual (usar este valor em preferência ao % DO BEM OBJETO)
  - "% ANTECIPADO" coluna PAGO -> resumo_financeiro.percentual_antecipado
- Conta Corrente:
  - Linhas com MOV. = "PGTO PARC" = parcelas normais pagas (usar para confirmar meses_pagos se divergir)
  - Linhas com MOV. = "TX DIVERSAS" = taxas diversas — NÃO contar como parcelas pagas
- Pendências (tabela PENDÊNCIAS):
  - Cada linha -> pendencias.proxima_parcela (vencimento=data, valor=valor da linha)
  - Se MOV. = "TX DIVERSAS" -> indicar no campo observacao como "Taxa especial" e NÃO tratar como parcela normal
- Resumo de Valores Pagos e a Pagar (última seção do documento):
  - "FUNDO COMUM" pago -> resumo_financeiro.valores_pagos.fundo_comum (valor) e fundo_comum_percentual (percentual)
  - "TAXA DE ADM." pago -> resumo_financeiro.valores_pagos.taxa_administracao e taxa_administracao_percentual
  - "FUNDO DE RESERVA" pago -> resumo_financeiro.valores_pagos.fundo_reserva
  - "RATEIO DE CAIXA" pago -> resumo_financeiro.valores_pagos.outros (campo EXCLUSIVO COIMEX, ignorar se ausente)
  - "MULTAS" pago -> resumo_financeiro.valores_pagos.multas
  - "JUROS" pago -> resumo_financeiro.valores_pagos.juros
  - "SEGURO" pago -> resumo_financeiro.valores_pagos.seguros
  - "TOTAL" pago -> resumo_financeiro.valores_pagos.total_pago (valor) e total_pago_percentual (percentual)
  - Mesma estrutura para seção "À PAGAR" -> resumo_financeiro.valores_a_pagar (usar campo "total" ao invés de "total_pago")

BANCO DO BRASIL CONSÓRCIOS:
- Identificar pelo sistema "SISBB" no rodapé ou título "Extrato de Cota" com referência ao BB
- Normalizar administradora para "BANCO DO BRASIL"
- O documento usa "Proposta" como campo equivalente ao número do contrato
  - Mapear "Proposta" para "contrato"
- "Prazo Contratado" mapear para "prazo_grupo_meses"
- "Data Adesão" mapear para "data_adesao"
- Seção "Dados da Contemplação":
  - "Data Contemplação" -> contemplacao.data_contemplacao
  - "Valor Crédito Contemplação" -> contemplacao.credito_original e dados_plano.valor_credito
  - "Contemplação por" -> contemplacao.tipo (LANCE, SORTEIO, etc.)
  - "Valor Crédito Liberado" -> contemplacao.valor_liquido
  - "Valor do Bem Atualizado" -> contemplacao.credito_corrigido
  - "Valor Disponível Carta Crédito" -> contemplacao.valor_disponivel_carta (campo exclusivo BB)
- Seção "Custos de Participação":
  - "Taxa Administração" (percentual) -> dados_plano.taxa_administracao
  - "Fundo Reserva" (percentual) -> dados_plano.fundo_reserva
- Seção "Parcelas Pagas" (tabela detalhada):
  - Contar parcelas com Data Pagamento preenchida = parcelas_pagas (meses_pagos)
  - Parcela sem Data Pagamento ou Valor Pago = 0,00 = pendente/futura
  - A primeira parcela pendente mapear para pendencias.proxima_parcela (numero, vencimento, valor)
  - Se Valor Devido != Valor Pago e Data Pagamento vazia = parcela em atraso ou futura
- Seção "Resumo de Pagamento" (Página 2):
  - Coluna "Parcelas Pagas" com Percentual e Valor -> resumo_financeiro.valores_pagos:
    - Fundo Comum: percentual -> fundo_comum_percentual, valor -> fundo_comum
    - Taxa Administração: percentual -> taxa_administracao_percentual, valor -> taxa_administracao
    - Fundo Reserva: percentual -> fundo_reserva_percentual, valor -> fundo_reserva
    - Seguro de Vida: valor -> seguros
    - Multa/juros: valor -> multas (somar multa + juros se separados)
    - TOTAL: valor -> total_pago
  - Coluna "Parcelas a Pagar" com Percentual e Valor -> resumo_financeiro.valores_a_pagar:
    - Mesma estrutura acima para valores pendentes
    - TOTAL: valor -> total
- Calcular meses_pagos contando parcelas efetivamente pagas na tabela de parcelas
- Calcular meses_a_pagar = prazo_contratado - meses_pagos

SANTANDER CONSÓRCIO:
- Identificar por "Santander" no documento ou "Central de atendimento Santander"
- Normalizar administradora para "SANTANDER"
- Consorciado:
  - "Nome" -> dados_cadastrais.nome
  - "CPF/CNPJ" -> dados_cadastrais.cpf (LIMPAR texto extra colado, ex: "168.410.987-65AUTOM" -> "168.410.987-65"; extrair apenas o padrão XXX.XXX.XXX-XX ou XX.XXX.XXX/XXXX-XX)
- Informações da Cota:
  - "Grupo" -> dados_plano.grupo
  - "Cota" -> dados_plano.cota (número antes do traço, ex: "01234-00" -> "01234")
  - "Contrato" -> dados_plano.contrato
  - "Data Contratação" -> dados_plano.data_adesao
  - "Situação da cota" -> dados_plano.sit_cobranca
  - "Modalidade" -> dados_plano.produto (normalizar: "AUTOMÓVEIS / PESADOS" -> "AUTOMOVEL", "IMÓVEIS" -> "IMOVEL", etc.)
  - "Valor Atualizado da carta" -> dados_plano.valor_credito (numérico, sem R$)
  - "1ª assembleia" -> dados_plano.primeira_assembleia
  - "Assembleia Atual" -> dados_plano.assembleia_atual (objeto com numero e data se disponível)
  - "Última assembleia" -> dados_plano.encerramento (data prevista de encerramento do grupo)
  - "Parcelas pagas" -> dados_plano.meses_pagos (inteiro)
  - "Parcelas restantes" -> dados_plano.meses_a_pagar (inteiro)
  - prazo_grupo_meses = meses_pagos + meses_restantes (calcular)
  - "Valores pagos" -> resumo_financeiro.valores_pagos.total_pago (numérico, sem R$)
  - "Saldo Devedor" -> resumo_financeiro.valores_a_pagar.total (numérico, sem R$)
  - "Data contemplação" -> contemplacao.data_contemplacao
  - "Valor do pagamento na contemplação" -> contemplacao.valor_bem_entregue (numérico)
- Pagamento(s) Realizado(s) (tabela):
  - Linhas "Parcela X/Y" = parcelas normais pagas (confirmar com campo "Parcelas pagas")
  - "RENDIMENTO PAGTO" = rendimento financeiro, NÃO contar como parcela
  - "CREDITO TROCA BEM" = troca de bem, NÃO contar como parcela
  - VL.PAGO de cada linha -> usar para somar total pago (confirmar com campo "Valores pagos")
  - valor_parcela_atual = VL.DEVIDO da última parcela paga com descrição "Parcela X/Y"
- Pagamento(s) atrasado(s)/pendentes(s) (tabela):
  - Primeira linha com "Parcela" -> pendencias.proxima_parcela (vencimento=VENCIMENTO, valor=VALOR DEVIDO)
  - "RECBTO. ANTECIPADO" -> indicar tipo especial na pendência, NÃO tratar como parcela normal
- NOTA: Santander não tem breakdown de fundo comum/taxa/reserva nos valores pagos — usar apenas total_pago e total a pagar

CAMPOS A EXTRAIR:

dados_cadastrais:
- nome: nome completo do cliente
- cpf: CPF formatado (adicionar pontuação se necessário)
- tipo_pessoa: "Física" ou "Jurídica" (se disponível)
- data_nascimento: data no formato ISO
- profissao: profissão do cliente (se disponível)
- documento_rg: número do RG/documento (se disponível)
- endereco: objeto com rua, numero, complemento, bairro, cidade, estado, cep
- telefone: número do telefone
- email: email se disponível

dados_plano:
- administradora: nome da administradora (EMBRACON, CAIXA, PORTO SEGURO, RODOBENS, etc)
- grupo: código do grupo
- cota: número da cota
- contrato: número do contrato
- data_venda: data da venda
- data_adesao: data de adesão
- tipo_venda: tipo da venda (COM LANCE EMBUTIDO, NORMAL, etc) - se disponível
- primeira_assembleia: data da primeira assembleia (se disponível)
- produto: tipo do produto normalizado (AUTOMOVEL, IMOVEL, SERVICO, MOTO, CAMINHAO)
- codigo_produto: código numérico do produto (se disponível)
- subproduto: subtipo se houver
- plano_basico_meses: prazo do plano básico em meses
- prazo_grupo_meses: prazo total do grupo em meses
- prazo_meses: prazo total em meses (usar prazo_grupo_meses se disponível)
- meses_pagos: quantidade de meses/parcelas já pagos
- meses_a_pagar: quantidade de meses restantes a pagar
- taxa_administracao: percentual da taxa de administração
- fundo_reserva: percentual do fundo de reserva
- percentual_mensal: percentual da contribuição mensal
- valor_parcela_atual: valor da parcela mensal atual
- bem: descrição do bem (usar campo "Bem" ou "Produto" dependendo da administradora)
- valor_credito: valor do crédito em número
- data_encerramento_grupo: data prevista para encerramento do grupo
- data_ultimo_vencimento: data do último vencimento da cota
- ultimo_reajuste: data do último reajuste do crédito (se disponível)
- sit_cobranca: situação de cobrança (NORMAL, ATRASO, etc) - se disponível
- assembleia_atual: objeto com data, numero, vencimento da próxima assembleia (se disponível)

contemplacao:
- data_contemplacao: data da contemplação
- tipo: tipo (Sorteio, Lance, Lance X pcls., etc)
- credito_original: valor original do crédito
- credito_corrigido: valor corrigido do crédito
- valor_bem_entregue: valor do bem já entregue (se houver)
- valor_liquido: valor líquido disponibilizado/a pagar

resumo_financeiro:
- valores_pagos: objeto contendo:
  - fundo_comum: valor pago
  - fundo_comum_percentual: percentual pago
  - fundo_reserva: valor pago
  - fundo_reserva_percentual: percentual pago
  - taxa_administracao: valor pago
  - taxa_administracao_percentual: percentual pago
  - seguros: valor pago em seguros
  - seguros_percentual: percentual pago em seguros
  - adesao: valor de adesão
  - adesao_percentual: percentual de adesão
  - multas: valor de multas
  - juros: valor de juros
  - outros_valores: outros valores pagos
  - total_pago: soma total de todos os valores
  - total_pago_percentual: percentual total pago (soma de todos %)
- valores_a_pagar: objeto contendo (se disponível):
  - fundo_comum: valor a pagar
  - fundo_comum_percentual: percentual a pagar
  - fundo_reserva: valor a pagar
  - fundo_reserva_percentual: percentual a pagar
  - taxa_administracao: valor a pagar
  - taxa_administracao_percentual: percentual a pagar
  - total: soma total dos valores a pagar
  - total_percentual: percentual total a pagar
- parcelas_pagas: número de parcelas já pagas
- parcelas_restantes: número de parcelas a pagar
- percentual_pago: percentual normal já pago
- percentual_pendente: percentual pendente
- percentual_a_cobrar: percentual restante a cobrar
- percentual_antecipado: percentual pago antecipadamente (se disponível)
- ideal_pago: percentual ideal que deveria estar pago (se disponível)

pendencias (se houver):
- proxima_parcela: objeto com numero, vencimento, valor
- parcelas_atrasadas: array de parcelas em atraso (se houver)

Se um campo não for encontrado, use null.
Retorne APENAS o JSON válido, sem markdown ou texto adicional.`;

  const userPrompt = `Analise este documento "${fileName}" e extraia as informações estruturadas:

${rawText.slice(0, 50000)}

Retorne um JSON com esta estrutura exata:
{
  "dados_cadastrais": { ... },
  "dados_plano": { ... },
  "contemplacao": { ... },
  "resumo_financeiro": { ... },
  "pendencias": { ... },
  "confidence": 0.95
}`;

  try {
    const response = await fetchWithRetry('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        temperature: 0.1,
        max_tokens: 16000,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI Gateway error:', response.status, errorText);
      throw new Error(`AI processing failed: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || '';
    
    // Extract and parse JSON with robust error handling, then normalize
    const rawParsed = cleanAndParseJSON(content);
    const parsed = normalizeStructuredData(rawParsed) as Record<string, Record<string, unknown> | number>;
    return {
      dados_cadastrais: (parsed.dados_cadastrais as Record<string, unknown>) || {} as Record<string, unknown>,
      dados_plano: (parsed.dados_plano as Record<string, unknown>) || {} as Record<string, unknown>,
      contemplacao: (parsed.contemplacao as Record<string, unknown>) || {} as Record<string, unknown>,
      resumo_financeiro: (parsed.resumo_financeiro as Record<string, unknown>) || {} as Record<string, unknown>,
      pendencias: (parsed.pendencias as Record<string, unknown>) || {} as Record<string, unknown>,
      confidence: (typeof parsed.confidence === 'number' ? parsed.confidence : 0.85)
    };
  } catch (error) {
    console.error('AI structuring error:', error);
    throw error; // Re-throw to be handled by caller
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return createErrorResponse(
      'INTERNAL_ERROR',
      'Method not allowed. Use POST.'
    );
  }

  try {
    const body: PDFRequest = await req.json();
    const { pdf_url } = body;

    if (!pdf_url) {
      return createErrorResponse(
        'INVALID_URL',
        'O campo pdf_url é obrigatório.'
      );
    }

    let url: URL;
    try {
      url = new URL(pdf_url);
    } catch {
      return createErrorResponse(
        'INVALID_URL',
        'A URL fornecida não é válida. Verifique o formato e tente novamente.'
      );
    }

    console.log(`Processing PDF from: ${pdf_url}`);

    // Download PDF
    let pdfResponse: Response;
    try {
      pdfResponse = await fetch(pdf_url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/pdf,application/octet-stream,*/*',
          'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        },
        redirect: 'follow'
      });
    } catch (fetchError) {
      console.error('Fetch error:', fetchError);
      return createErrorResponse(
        'DOWNLOAD_FAILED',
        'Não foi possível conectar à URL. Verifique se o link está acessível.'
      );
    }

    if (!pdfResponse.ok) {
      return createErrorResponse(
        'DOWNLOAD_FAILED',
        `Falha ao baixar o PDF: HTTP ${pdfResponse.status}. Verifique se a URL está correta e acessível.`
      );
    }

    const contentType = pdfResponse.headers.get('content-type') || '';
    const warnings: string[] = [];
    
    // Fail fast if server returned HTML or multipart instead of PDF
    if (contentType.includes('text/html')) {
      return createErrorResponse(
        'NOT_A_PDF',
        `O servidor retornou HTML (Content-Type: ${contentType}). O link pode ter expirado ou requer autenticação.`,
        warnings
      );
    }
    
    if (contentType.includes('multipart/')) {
      return createErrorResponse(
        'NOT_A_PDF',
        `O servidor retornou dados multipart (Content-Type: ${contentType}). O link pode ter expirado ou requer tokens de autenticação.`,
        warnings
      );
    }
    
    if (!contentType.includes('pdf') && !contentType.includes('octet-stream')) {
      warnings.push(`Content-Type é "${contentType}", esperado application/pdf`);
    }

    let pdfBuffer = await pdfResponse.arrayBuffer();
    const fileSizeBytes = pdfBuffer.byteLength;
    
    // Check for empty PDF
    if (fileSizeBytes < 100) {
      return createErrorResponse(
        'EMPTY_PDF',
        'O arquivo PDF está vazio ou é muito pequeno para ser processado.',
        warnings
      );
    }

    console.log(`PDF downloaded: ${fileSizeBytes} bytes from ${pdfResponse.url || pdf_url}`);

    // Reject PDFs that are too large for edge function memory limits
    const MAX_PDF_SIZE = 5 * 1024 * 1024; // 5MB
    if (fileSizeBytes > MAX_PDF_SIZE) {
      const sizeMB = (fileSizeBytes / (1024 * 1024)).toFixed(1);
      return createErrorResponse(
        'FILE_TOO_LARGE',
        `O PDF tem ${sizeMB}MB, excedendo o limite de 5MB. PDFs de consórcio geralmente têm menos de 1MB. Verifique se o arquivo correto foi enviado.`,
        warnings
      );
    }
    
    // Check if it's a valid PDF - read more bytes for better detection
    const header = new Uint8Array(pdfBuffer.slice(0, 100));
    const headerStr = String.fromCharCode(...header);
    
    if (!headerStr.startsWith('%PDF')) {
      // Detect if content is HTML (error page / login page)
      if (headerStr.includes('<!DOCTYPE') || headerStr.includes('<html') || headerStr.includes('<HTML') || headerStr.includes('<?xml')) {
        return createErrorResponse(
          'NOT_A_PDF',
          'O servidor retornou uma página HTML ao invés do PDF. O link pode ter expirado, requer autenticação, ou não está acessível publicamente.',
          warnings
        );
      }
      
      // Detect multipart response - try to extract PDF from inside
      if (headerStr.includes('--') && (headerStr.includes('Content-Disposition') || headerStr.includes('boundary'))) {
        console.log('Detected multipart response, attempting to extract PDF...');
        
        const extractedPdf = extractPdfFromMultipart(pdfBuffer);
        
        if (extractedPdf) {
          console.log(`Extracted PDF from multipart: ${extractedPdf.byteLength} bytes`);
          // Replace pdfBuffer with extracted content
          pdfBuffer = extractedPdf;
          
          // Verify extraction was successful
          const newHeader = new Uint8Array(pdfBuffer.slice(0, 5));
          const newHeaderStr = String.fromCharCode(...newHeader);
          
          if (!newHeaderStr.startsWith('%PDF')) {
            return createErrorResponse(
              'NOT_A_PDF',
              'Falha ao extrair PDF da resposta multipart. O conteúdo extraído não é um PDF válido.',
              warnings
            );
          }
          
          warnings.push('PDF extraído de resposta multipart do servidor');
          // Successfully extracted - continue to processing below
        } else {
          return createErrorResponse(
            'NOT_A_PDF',
            'O servidor retornou dados multipart mas não foi possível extrair o PDF. O link pode ter expirado ou estar corrompido.',
            warnings
          );
        }
      } else {
        // Not multipart, show first bytes for debugging unknown formats
        const firstBytes = headerStr.slice(0, 50).replace(/[^\x20-\x7E]/g, '?');
        return createErrorResponse(
          'NOT_A_PDF',
          `O arquivo não é um PDF válido. Início do arquivo: "${firstBytes}..."`,
          warnings
        );
      }
    }

    // Check for encrypted PDF - only block if we can't process it
    // Many "encrypted" PDFs have empty passwords and are readable
    const encryptionCheck = isPDFEncrypted(pdfBuffer);
    if (encryptionCheck.encrypted) {
      if (encryptionCheck.hasRealPassword) {
        warnings.push('PDF possui criptografia com senha - tentando processar com Vision API');
      } else {
        warnings.push('PDF possui marcadores de criptografia mas sem senha real');
      }
      // Don't block - let Vision API try to read it
      console.log('PDF has encryption markers, but will attempt Vision API extraction');
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      return createErrorResponse(
        'INTERNAL_ERROR',
        'Chave de API não configurada. Contate o suporte.',
        warnings
      );
    }

    // Use Vision API as primary method (more reliable for compressed PDFs)
    let extractionMethod: 'programmatic' | 'vision_api' = 'vision_api';
    let extractedText = '';
    let pageCount = 1;
    
    console.log('Attempting Vision API extraction (primary method)...');
    
    try {
      const visionResult = await extractWithVisionAPI(pdfBuffer, LOVABLE_API_KEY);
      extractedText = visionResult.text;
      pageCount = visionResult.pageCount;
      
      // Verify Vision API returned valid content
      if (!extractedText || extractedText.length < 100) {
        throw new Error('Vision API returned insufficient content');
      }
      
      console.log('Vision API extraction successful');
    } catch (visionError) {
      // Fallback to programmatic extraction only if Vision API fails
      console.log('Vision API failed, trying programmatic extraction as fallback:', visionError);
      warnings.push('Extração via Vision API falhou. Tentando extração programática.');
      
      const programmaticResult = extractTextFromPDF(pdfBuffer);
      
      if (programmaticResult.isReadable && programmaticResult.pages.length > 0) {
        console.log('Programmatic extraction successful');
        extractedText = programmaticResult.pages.join('\n\n--- NOVA PÁGINA ---\n\n');
        pageCount = programmaticResult.pageCount;
        extractionMethod = 'programmatic';
      } else {
        console.error('Both extraction methods failed');
        return createErrorResponse(
          'EXTRACTION_FAILED',
          'Não foi possível extrair texto do PDF. O documento pode estar corrompido, ser apenas imagens sem camada de texto, ou usar uma codificação não suportada.',
          warnings
        );
      }
    }

    // Free PDF buffer memory before AI structuring
    pdfBuffer = null as any;

    // Build raw content by page
    const contentRaw: Record<string, string> = {};
    if (extractionMethod === 'vision_api') {
      // Parse Vision API output which has "--- PÁGINA X ---" separators
      const pageRegex = /---\s*PÁGINA\s*(\d+)\s*---\s*([\s\S]*?)(?=---\s*PÁGINA\s*\d+\s*---|$)/gi;
      let match;
      while ((match = pageRegex.exec(extractedText)) !== null) {
        const pageNum = match[1];
        const pageText = match[2].trim();
        contentRaw[`page_${pageNum}`] = pageText;
      }
      // If no pages found, put all in page_1
      if (Object.keys(contentRaw).length === 0) {
        contentRaw['page_1'] = extractedText;
      }
    } else {
      // Programmatic extraction
      const pages = extractedText.split(/---\s*NOVA\s*PÁGINA\s*---/i);
      pages.forEach((page, i) => {
        contentRaw[`page_${i + 1}`] = page.trim();
      });
    }

    // Get file name from URL
    const pathParts = url.pathname.split('/');
    const fileName = pathParts[pathParts.length - 1] || 'document.pdf';

    // Validate extracted content before structuring
    const validation = validateExtractedContent(contentRaw);
    if (!validation.valid) {
      console.error('Content validation failed:', validation.reason);
      return createErrorResponse(
        'UNREADABLE_CONTENT',
        `O conteúdo extraído está corrompido ou ilegível. ${validation.reason}. O PDF pode usar uma codificação não suportada ou ser baseado apenas em imagens sem camada de texto.`,
        warnings
      );
    }

    // Clean content if it has binary noise but enough readable words
    let allText = Object.values(contentRaw).join('\n\n');
    if (validation.cleaned) {
      console.log('Cleaning binary noise from extracted text...');
      // Remove control characters and non-printable bytes, keep readable text
      allText = allText.replace(/[\x00-\x08\x0B\x0E-\x1F\x7F-\x9F]/g, ' ')
                       .replace(/\s{3,}/g, ' ')
                       .trim();
      console.log(`Cleaned text length: ${allText.length}`);
    }

    // Structure the document with AI
    let structured;
    
    try {
      structured = await structureFinancialDocument(allText, fileName, LOVABLE_API_KEY);
    } catch (aiError) {
      console.error('AI structuring failed:', aiError);
      return createErrorResponse(
        'AI_PROCESSING_FAILED',
        'Falha ao processar o documento com IA. O conteúdo pode estar em um formato não reconhecido.',
        warnings
      );
    }

    console.log(`Processing complete. Method: ${extractionMethod}, Confidence: ${structured.confidence}`);

    // Determine status based on confidence
    let status: 'success' | 'partial' = 'success';
    if (structured.confidence < 0.5) {
      status = 'partial';
      warnings.push(`Baixa confiança na extração (${Math.round(structured.confidence * 100)}%). Alguns dados podem estar incorretos ou faltando.`);
    }

    const response: PDFResponse = {
      status,
      metadata: {
        pages: pageCount,
        file_name: fileName,
        processed_at: new Date().toISOString(),
        file_size_bytes: fileSizeBytes,
        extraction_method: extractionMethod
      },
      content_raw: contentRaw,
      content_structured: {
        dados_cadastrais: structured.dados_cadastrais,
        dados_plano: structured.dados_plano,
        contemplacao: structured.contemplacao,
        resumo_financeiro: structured.resumo_financeiro,
        pendencias: structured.pendencias
      },
      warnings,
      confidence_score: Math.round(structured.confidence * 100) / 100
    };

    return new Response(
      JSON.stringify(response, null, 2),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Processing error:', error);
    
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    
    return createErrorResponse(
      'INTERNAL_ERROR',
      `Erro interno: ${errorMessage}`
    );
  }
});
