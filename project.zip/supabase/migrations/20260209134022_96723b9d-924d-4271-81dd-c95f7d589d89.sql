
INSERT INTO storage.buckets (id, name, public) VALUES ('test-pdfs', 'test-pdfs', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Public read access for test-pdfs" ON storage.objects FOR SELECT USING (bucket_id = 'test-pdfs');
CREATE POLICY "Allow uploads to test-pdfs" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'test-pdfs');
